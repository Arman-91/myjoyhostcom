<?php
/** Silence is golden.
